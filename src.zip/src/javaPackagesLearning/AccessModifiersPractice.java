package javaPackagesLearning;

public class AccessModifiersPractice {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}
	
	void defaultModifierExample() {
		System.out.println("This is an example for Default access modifier");
	}
	
	private void privateModifierExample() {
		System.out.println("This is an example for Private Access modifer");
	}
	
	
	protected void protectedModifierExample() {
		System.out.println("This is an example for Protected access modifier");
	}
	
	

}
