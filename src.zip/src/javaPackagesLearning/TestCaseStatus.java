package javaPackagesLearning;

public enum TestCaseStatus {
	PASS,
	FAIL,
	SKIPPED,
	HOLD,
	NOT_EXECUTED;
}
