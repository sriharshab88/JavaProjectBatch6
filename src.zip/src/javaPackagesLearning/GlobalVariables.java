package javaPackagesLearning;

public class GlobalVariables {

	public static final String browser1 = "Chrome";
	public static String browser2 = "Firefox";
	public static String browser3 = "Safari";
	public static String operatingSystem1 = "Windows";
	public static final String operatingSystem2 = "Mac OS";
	public static String operatingSystem3 = "Linux";
	public static final String applicationUrl = "https://amazon.in/";
	public static final String stageApplicationUrl = "https://test.amazon.in/";
	
	
}
