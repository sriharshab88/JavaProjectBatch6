package javaBasicSession;

public class JavaObjectsAndClasses {
	
	public static String classVariable;
	String instanceVariable = "This is a new variable outside method";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sessionName = "Java Selenium Batch 7";
		int numberOfClasses = 5;
		int localVariable = 7;
		
		System.out.println(sessionName+localVariable);
	}
	
}

