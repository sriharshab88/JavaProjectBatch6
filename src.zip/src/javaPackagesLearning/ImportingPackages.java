package javaPackagesLearning;

import javaBasicSession.JavaCallingOfMethods;
import javaBasicSession.JavaMethods;

public class ImportingPackages {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//JavaMethods.LoginToAmazon("", "");
		//JavaCallingOfMethods javaCallingOfMethods = new JavaCallingOfMethods();
		AccessModifiersPractice accessModifiersPractice = new AccessModifiersPractice();
		accessModifiersPractice.defaultModifierExample();
		accessModifiersPractice.protectedModifierExample();
	}

}
