package javaPackagesLearning;

public abstract class ExampleForAbstractModifier {

	public abstract void launchingBrowser();
	public abstract void launchApplication();
}
