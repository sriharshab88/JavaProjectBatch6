package javaBasicSession;

public class JavaMethodsAndVariables {
	
	String name = "Java and Selenium";
	//type  objectname  = value of object
	
	String names = "Sriharsha";
	
	public static void main(String[] args) {
		JavaObjectsAndClasses javaObjectsAndVariables = new JavaObjectsAndClasses();
	
		String sessionName = "JAVA";
		int oddNumber = 11;	
		
		javaObjectsAndVariables.instanceVariable = "new variable value";
		
		
		JavaObjectsAndClasses.classVariable = "";
	}

}
